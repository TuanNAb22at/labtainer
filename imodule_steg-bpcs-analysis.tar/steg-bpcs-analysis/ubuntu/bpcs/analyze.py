import cv2
import numpy as np

cap = cv2.VideoCapture('input.mp4')
ret, frame = cap.read()

if not ret:
    print("cannot_read_video")
    exit()

print("loaded_frame")

gray = cv2.cvtColor(frame, cv2.COLOR_BGR2GRAY)

bit_planes = []
for i in range(8):
    plane = (gray >> i) & 1
    bit_planes.append(plane)

print("created_8_bit_planes")

def complexity(block):
    h_diff = np.sum(block[:, :-1] != block[:, 1:])
    v_diff = np.sum(block[:-1, :] != block[1:, :])
    return (h_diff + v_diff) / 112.0

threshold = 0.3
noisy = 0
info = 0

for plane in bit_planes:
    h, w = plane.shape
    for i in range(0, h, 8):
        for j in range(0, w, 8):
            block = plane[i:i+8, j:j+8]
            if block.shape == (8, 8):
                c = complexity(block)
                if c >= threshold:
                    noisy += 1
                else:
                    info += 1

print("noisy_blocks:", noisy)
print("info_blocks:", info)
print("analysis_done")

# ghi file cho grader
with open("/home/student/result.txt", "w") as f:
    f.write("created_8_bit_planes\n")
    f.write("noisy_blocks\n")
    f.write("analysis_done\n")

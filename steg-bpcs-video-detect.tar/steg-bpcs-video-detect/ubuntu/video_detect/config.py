# =========================================================
# CONFIG
# =========================================================

# TODO
BLOCK_SIZE = 0

# TODO
THRESHOLD = 0.0

# TODO
SUSPICIOUS_THRESHOLD = 0.0

SUSPECT_VIDEO = "suspect.mp4"

ORIGINAL_VIDEO = "original.mp4"

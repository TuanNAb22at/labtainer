import numpy as np
from config import *


# =========================================================
# Extract Bit Planes
# =========================================================

def extract_bit_planes(gray_frame):

    bit_planes = []

    for i in range(8):

        # TODO:
        # Extract i-th bit plane using bitwise operations
        plane = None

        bit_planes.append(plane)

    return bit_planes


# =========================================================
# Split Blocks
# =========================================================

def split_blocks(bit_plane):

    blocks = []

    h, w = bit_plane.shape

    for y in range(0, h, BLOCK_SIZE):
        for x in range(0, w, BLOCK_SIZE):

            block = bit_plane[
                y:y + BLOCK_SIZE,
                x:x + BLOCK_SIZE
            ]

            if block.shape == (BLOCK_SIZE, BLOCK_SIZE):
                blocks.append(block)

    return blocks


# =========================================================
# Calculate Complexity
# =========================================================

def calculate_complexity(block):

    h, w = block.shape

    # TODO:
    # Compute horizontal transitions
    horizontal_changes = None

    # TODO:
    # Compute vertical transitions
    vertical_changes = None

    transitions = horizontal_changes + vertical_changes

    maximum_transitions = h * (w - 1) + (h - 1) * w

    if maximum_transitions == 0:
        return 0.0

    # TODO:
    # Compute alpha complexity
    alpha = None

    return alpha


# =========================================================
# Calculate Entropy
# =========================================================

def calculate_entropy(block):

    unique, counts = np.unique(block, return_counts=True)
    probabilities = counts / counts.sum()

    entropy = -np.sum(
        probabilities * np.log2(probabilities + 1e-10)
    )

    return entropy


# =========================================================
# Noise Block Detection
# =========================================================

def is_noise_block(alpha):

    # TODO:
    # Return True if block is considered noisy
    return None

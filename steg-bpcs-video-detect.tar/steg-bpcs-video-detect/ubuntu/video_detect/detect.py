import cv2
import csv

from config import *
from analysis import (
    extract_bit_planes,
    split_blocks,
    calculate_complexity,
    calculate_entropy,
    is_noise_block
)

# =========================================================
# FORCE OUTPUT DIRECTORY (CHECKWORK SAFE)
# =========================================================

BASE_DIR = "/home/student"

result_path = BASE_DIR + "/result.txt"
csv_path = BASE_DIR + "/analysis.csv"
report_path = BASE_DIR + "/report.txt"
suspicious_path = BASE_DIR + "/suspicious_frames.txt"

# =========================================================
# Validate Config
# =========================================================

if BLOCK_SIZE <= 0:
    print("invalid_block_size")
    exit()

if THRESHOLD <= 0:
    print("invalid_threshold")
    exit()

if SUSPICIOUS_THRESHOLD <= 0:
    print("invalid_suspicious_threshold")
    exit()

# =========================================================
# INIT OUTPUT FILES
# =========================================================

with open(result_path, "w") as f:
    f.write("loaded_video\n")

with open(csv_path, "w", newline="") as f:
    writer = csv.writer(f)
    writer.writerow([
        "frame",
        "plane",
        "avg_complexity",
        "avg_entropy",
        "noise_ratio"
    ])

# =========================================================
# LOAD VIDEO
# =========================================================

cap = cv2.VideoCapture(SUSPECT_VIDEO)

if not cap.isOpened():
    print("cannot_open_video")
    exit()

print("Starting BPCS Video Detection")

# =========================================================
# ANALYZE
# =========================================================

frame_idx = 0
suspicious_frames = []

with open(csv_path, "a", newline="") as f:
    writer = csv.writer(f)

    while True:
        ret, frame = cap.read()
        if not ret:
            break

        gray = cv2.cvtColor(frame, cv2.COLOR_BGR2GRAY)

        # TODO 1: extract bit-planes from grayscale frame
        bit_planes = None

        with open(result_path, "a") as r:
            r.write("bit_plane_analysis_done\n")

        for plane_idx, plane in enumerate(bit_planes):

            # TODO 2: split bit-plane into blocks
            blocks = None

            total_complexity = 0
            total_entropy = 0
            noise_blocks = 0
            for block in blocks:
                alpha = calculate_complexity(block)
                entropy = calculate_entropy(block)

                total_complexity += alpha
                total_entropy += entropy

                # TODO 3: determine noisy block condition
                if None:
                    noise_blocks += 1

            if len(blocks) > 0:
                avg_complexity = total_complexity / len(blocks)
                avg_entropy = total_entropy / len(blocks)
                noise_ratio = noise_blocks / len(blocks)
            else:
                avg_complexity = 0
                avg_entropy = 0
                noise_ratio = 0

            writer.writerow([
                frame_idx,
                plane_idx,
                avg_complexity,
                avg_entropy,
                noise_ratio
            ])

            if noise_ratio >= SUSPICIOUS_THRESHOLD:
                suspicious_frames.append((frame_idx, plane_idx, noise_ratio))

        print(f"Frame {frame_idx} analyzed")
        frame_idx += 1

with open(result_path, "a") as f:
    f.write("analyzed_frames\n")

cap.release()

# =========================================================
# REPORT
# =========================================================

with open(report_path, "w") as f:
    f.write("Suspicious Frames Report\n")
    f.write("=========================\n\n")

    for item in suspicious_frames:
        f.write(f"Frame {item[0]} Plane {item[1]} Noise {item[2]:.4f}\n")

# =========================================================
# SUSPICIOUS FILE
# =========================================================

with open(suspicious_path, "w") as f:
    for item in suspicious_frames:
        f.write(f"Frame {item[0]} Noise Detected\n")

with open(result_path, "a") as f:
    f.write("detect_done\n")

print("Detection Complete")
print(f"Suspicious detections: {len(suspicious_frames)}")

import cv2
import os


def load_video(path):

    cap = cv2.VideoCapture(path)

    frames = []

    while True:

        ret, frame = cap.read()

        if not ret:
            break

        frames.append(frame)

    cap.release()

    return frames


def create_output_dirs():

    folders = [
        "output",
        "output/plots",
        "output/suspicious"
    ]

    for folder in folders:

        os.makedirs(folder, exist_ok=True)


def save_suspicious_frame(frame, idx):

    path = f"output/suspicious/frame_{idx}.png"

    cv2.imwrite(path, frame)


def write_result(tag):

    with open("result.txt", "a") as f:

        f.write(tag + "\n")

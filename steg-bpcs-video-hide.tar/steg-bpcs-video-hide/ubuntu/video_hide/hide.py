import cv2
import numpy as np
import os
import hashlib
import random

VIDEO_PATH = "input.mp4"
SECRET_PATH = "secret.txt"
OUTPUT_DIR = "output"
RESULT_PATH = "/home/student/result.txt"

STEGO_VIDEO_PATH = os.path.join(OUTPUT_DIR, "stego_output.mp4")
KEY_PATH = os.path.join(OUTPUT_DIR, "key.txt")

# TODO 1:
# Change BLOCK_SIZE to 8
BLOCK_SIZE = 0

# TODO 2:
# Change THRESHOLD to 0.3
THRESHOLD = 0.0

# TODO 3:
# Set a non-empty secret key
SECRET_KEY = ""

os.makedirs(OUTPUT_DIR, exist_ok=True)


def text_to_bits(text):
    data = text.encode("utf-8")
    bits = ""

    for byte in data:
        bits += format(byte, "08b")

    return bits


def bits_to_block(bits):
    block = np.zeros((BLOCK_SIZE, BLOCK_SIZE), dtype=np.uint8)

    index = 0

    for y in range(BLOCK_SIZE):
        for x in range(BLOCK_SIZE):
            if index < len(bits):
                block[y, x] = int(bits[index])
            else:
                block[y, x] = 0

            index += 1

    return block


def calculate_complexity(block):
    # TODO 4:
    # Complete this function.
    #
    # Requirement:
    # Count horizontal and vertical bit transitions.
    # alpha = transitions / maximum_transitions
    raise NotImplementedError("Student must complete calculate_complexity")


def is_noise_block(alpha):
    # TODO 5:
    # alpha >= 0.3 means noise block
    return False


def select_frame_indexes(total_frames, key, number_of_frames):
    seed = int(hashlib.sha256(key.encode()).hexdigest(), 16)

    rng = random.Random(seed)

    indexes = list(range(total_frames))
    rng.shuffle(indexes)

    return sorted(indexes[:number_of_frames])


def embed_bits_into_frame(gray_frame, message_bits, start_index):
    bit_planes = []

    for bit in range(8):
        plane = ((gray_frame >> bit) & 1).astype(np.uint8)
        bit_planes.append(plane)

    h, w = gray_frame.shape

    bit_index = start_index

    for plane_id in [0, 1]:
        plane = bit_planes[plane_id]

        for y in range(0, h - BLOCK_SIZE + 1, BLOCK_SIZE):
            for x in range(0, w - BLOCK_SIZE + 1, BLOCK_SIZE):

                if bit_index >= len(message_bits):
                    break

                block = plane[y:y + BLOCK_SIZE, x:x + BLOCK_SIZE]

                alpha = calculate_complexity(block)

                if is_noise_block(alpha):

                    chunk = message_bits[bit_index:bit_index + 64]

                    new_block = bits_to_block(chunk)

                    plane[y:y + BLOCK_SIZE, x:x + BLOCK_SIZE] = new_block

                    bit_index += len(chunk)

            if bit_index >= len(message_bits):
                break

        bit_planes[plane_id] = plane

        if bit_index >= len(message_bits):
            break

    stego_gray = np.zeros_like(gray_frame)

    for bit in range(8):
        stego_gray |= (bit_planes[bit] << bit)

    return stego_gray, bit_index


if BLOCK_SIZE != 8:
    print("invalid_block_size")
    exit(1)

if THRESHOLD != 0.3:
    print("invalid_threshold")
    exit(1)

if SECRET_KEY == "":
    print("invalid_secret_key")
    exit(1)


if not os.path.exists(VIDEO_PATH):
    print("missing_input_video")
    exit(1)

if not os.path.exists(SECRET_PATH):
    print("missing_secret_file")
    exit(1)


with open(SECRET_PATH, "r", encoding="utf-8") as f:
    secret_message = f.read().strip()

message_bits = text_to_bits(secret_message)

cap = cv2.VideoCapture(VIDEO_PATH)

if not cap.isOpened():
    print("cannot_open_video")
    exit(1)

fps = cap.get(cv2.CAP_PROP_FPS)

width = int(cap.get(cv2.CAP_PROP_FRAME_WIDTH))
height = int(cap.get(cv2.CAP_PROP_FRAME_HEIGHT))

total_frames = int(cap.get(cv2.CAP_PROP_FRAME_COUNT))

selected_frames = select_frame_indexes(
    total_frames,
    SECRET_KEY,
    5
)

fourcc = cv2.VideoWriter_fourcc(*"mp4v")

writer = cv2.VideoWriter(
    STEGO_VIDEO_PATH,
    fourcc,
    fps,
    (width, height)
)

frame_index = 0
bit_index = 0

while True:
    ret, frame = cap.read()

    if not ret:
        break

    if frame_index in selected_frames:

        gray = cv2.cvtColor(frame, cv2.COLOR_BGR2GRAY)

        stego_gray, bit_index = embed_bits_into_frame(
            gray,
            message_bits,
            bit_index
        )

        stego_frame = cv2.cvtColor(
            stego_gray,
            cv2.COLOR_GRAY2BGR
        )

        writer.write(stego_frame)

    else:
        writer.write(frame)

    frame_index += 1

cap.release()
writer.release()

if bit_index < len(message_bits):
    print("message_not_fully_embedded")
    exit(1)

with open(KEY_PATH, "w") as f:
    f.write("secret_key=" + SECRET_KEY + "\n")
    f.write(
        "selected_frames=" +
        ",".join(map(str, selected_frames))
    )

print("loaded_video")
print("selected_frames")
print("converted_secret_to_bits")
print("bpcs_blocks_selected")
print("message_embedded")
print("stego_video_created")
print("key_saved")
print("hide_done")

with open(RESULT_PATH, "w") as f:
    f.write("loaded_video\n")
    f.write("selected_frames\n")
    f.write("converted_secret_to_bits\n")
    f.write("bpcs_blocks_selected\n")
    f.write("message_embedded\n")
    f.write("stego_video_created\n")
    f.write("key_saved\n")
    f.write("hide_done\n")

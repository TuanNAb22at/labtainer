import cv2
import numpy as np


# =========================================================
# Convert To Gray
# =========================================================

def convert_gray(frame):

    # TODO:
    # Complete grayscale conversion

    gray = None

    return gray


# =========================================================
# Extract Bit Planes
# =========================================================

def extract_bit_planes(gray_frame):

    bit_planes = []

    for i in range(8):

        # TODO:
        # Complete bit-plane extraction

        plane = None

        bit_planes.append(plane)

    return bit_planes


FRAME_INDEX = -1

VIDEO_PATH = "input.mp4"

RESULT_PATH = "/home/student/result.txt"

OUTPUT_DIR = "/home/student/output"

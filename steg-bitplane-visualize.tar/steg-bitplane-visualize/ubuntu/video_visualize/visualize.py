import cv2
import os

from config import *
from analysis import (
    convert_gray,
    extract_bit_planes
)

# =========================================================
# Create Output
# =========================================================

os.makedirs(
    OUTPUT_DIR,
    exist_ok=True
)

# =========================================================
# Validate Config
# =========================================================

if FRAME_INDEX < 0:

    print("invalid_frame_index")
    exit()

# =========================================================
# Load Video
# =========================================================

print("[+] Loading video...")

cap = cv2.VideoCapture(
    VIDEO_PATH
)

if not cap.isOpened():

    print("cannot_open_video")
    exit()

# =========================================================
# Read Frames
# =========================================================

frame_count = 0

selected_frame = None

while True:

    ret, frame = cap.read()

    if not ret:
        break

    if frame_count == FRAME_INDEX:

        selected_frame = frame

        break

    frame_count += 1

cap.release()

if selected_frame is None:

    print("frame_not_found")
    exit()

# =========================================================
# Save Original Frame
# =========================================================

cv2.imwrite(
    f"{OUTPUT_DIR}/frame.png",
    selected_frame
)

# =========================================================
# Convert Gray
# =========================================================

gray = convert_gray(
    selected_frame
)

cv2.imwrite(
    f"{OUTPUT_DIR}/gray.png",
    gray
)

# =========================================================
# Extract Bit Planes
# =========================================================

bit_planes = extract_bit_planes(
    gray
)

# =========================================================
# Save Bit Planes
# =========================================================

for i, plane in enumerate(bit_planes):

    # TODO:
    # Complete bit-plane save

    cv2.imwrite(
        "",
        plane * 255
    )

# =========================================================
# Result
# =========================================================

with open(RESULT_PATH, "w") as f:

    f.write(
        "visualization_done\n"
    )

print("[+] Bit-plane visualization complete")

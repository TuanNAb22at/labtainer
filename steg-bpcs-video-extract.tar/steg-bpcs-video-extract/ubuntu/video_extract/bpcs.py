import cv2
import numpy as np

from config import *

# =========================================================
# Convert Gray
# =========================================================

def convert_gray(frame):

    return cv2.cvtColor(
        frame,
        cv2.COLOR_BGR2GRAY
    )

# =========================================================
# Extract Bit Planes
# =========================================================

def extract_bit_planes(gray_frame):

    bit_planes = []

    for i in range(8):

        plane = (
            gray_frame >> i
        ) & 1

        bit_planes.append(
            plane
        )

    return bit_planes

# =========================================================
# Split Blocks
# =========================================================

def split_blocks(bit_plane):

    h, w = bit_plane.shape

    blocks = []

    for y in range(
        0,
        h - BLOCK_SIZE + 1,
        BLOCK_SIZE
    ):

        for x in range(
            0,
            w - BLOCK_SIZE + 1,
            BLOCK_SIZE
        ):

            block = bit_plane[
                y:y + BLOCK_SIZE,
                x:x + BLOCK_SIZE
            ]

            blocks.append(block)

    return blocks

# =========================================================
# Calculate Complexity
# =========================================================

def calculate_complexity(block):

    # TODO:
    # Complete complexity calculation

    return 0

# =========================================================
# Detect Noise Block
# =========================================================

def is_noise_block(alpha):

    # TODO:
    # Complete noise detection

    return False

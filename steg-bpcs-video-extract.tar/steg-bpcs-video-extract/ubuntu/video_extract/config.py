BLOCK_SIZE = 0

THRESHOLD = 0.0

SECRET_KEY = ""

VIDEO_PATH = "stego_video.mp4"

OUTPUT_DIR = "/home/student/output"

RESULT_PATH = "/home/student/result.txt"

import cv2
import os

from config import *

from bpcs import (
    convert_gray,
    extract_bit_planes,
    split_blocks,
    calculate_complexity,
    is_noise_block
)

# =========================================================
# Validate Config
# =========================================================

if BLOCK_SIZE <= 0:

    print("invalid_block_size")
    exit()

if THRESHOLD <= 0:

    print("invalid_threshold")
    exit()

if SECRET_KEY == "":

    print("invalid_secret_key")
    exit()

# =========================================================
# Create Output
# =========================================================

os.makedirs(
    OUTPUT_DIR,
    exist_ok=True
)

# =========================================================
# Load Video
# =========================================================

print("[+] Loading video...")

cap = cv2.VideoCapture(
    VIDEO_PATH
)

if not cap.isOpened():

    print("cannot_open_video")
    exit()

with open(RESULT_PATH, "w") as f:

    f.write(
        "loaded_video\n"
    )

# =========================================================
# Read Key
# =========================================================

selected_frames = []

with open("key.txt", "r") as f:

    for line in f:

        selected_frames.append(
            int(line.strip())
        )

with open(RESULT_PATH, "a") as f:

    f.write(
        "selected_frames\n"
    )

# =========================================================
# Extract Message
# =========================================================

secret_bits = ""

frame_idx = 0

while True:

    ret, frame = cap.read()

    if not ret:
        break

    if frame_idx not in selected_frames:

        frame_idx += 1

        continue

    gray = convert_gray(
        frame
    )

    bit_planes = extract_bit_planes(
        gray
    )

    for plane in bit_planes:

        blocks = split_blocks(plane)

        for block in blocks:

            alpha = calculate_complexity(block)

            if is_noise_block(alpha):
		#TODO:
                # extract bit from noisy block 
              


                

    print(
        f"[+] Frame {frame_idx} analyzed"
    )

    frame_idx += 1

# =========================================================
# Save Message
# =========================================================

with open(
    f"{OUTPUT_DIR}/extracted_message.txt",
    "w"
) as f:

    f.write(
        secret_bits
    )

# =========================================================
# Save Report
# =========================================================

with open(
    f"{OUTPUT_DIR}/report.txt",
    "w"
) as f:

    f.write(
        "Extraction Complete\n"
    )

# =========================================================
# Result
# =========================================================

with open(
    RESULT_PATH,
    "a"
) as f:

    f.write(
        "message_extracted\n"
    )

    f.write(
        "extract_done\n"
    )

cap.release()

print("[+] Extraction complete")

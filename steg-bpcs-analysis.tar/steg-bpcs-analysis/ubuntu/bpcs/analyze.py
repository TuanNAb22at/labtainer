import cv2
import numpy as np
import os

VIDEO_PATH = "input.mp4"
RESULT_PATH = "/home/student/result.txt"
OUTPUT_DIR = "output"

# TODO 1:
# Change BLOCK_SIZE to 8
BLOCK_SIZE = 0

# TODO 2:
# Change THRESHOLD to 0.3
THRESHOLD = 0.0

os.makedirs(OUTPUT_DIR, exist_ok=True)


def calculate_complexity(block):
    # TODO 3:
    # Complete this function.
    #
    # Requirement:
    # Count horizontal and vertical bit transitions.
    # alpha = transitions / maximum_transitions
    #
    # For an 8x8 block:
    # maximum_transitions = 8 * 7 + 7 * 8 = 112
    #
    # Return alpha.
    raise NotImplementedError("Student must complete calculate_complexity")


def classify_block(alpha):
    # TODO 4:
    # Fix this condition.
    #
    # Requirement:
    # alpha >= 0.3 means noise block.
    # alpha < 0.3 means information block.
    return "information"


if BLOCK_SIZE != 8:
    print("invalid_block_size")
    exit(1)

if THRESHOLD != 0.3:
    print("invalid_threshold")
    exit(1)


cap = cv2.VideoCapture(VIDEO_PATH)
ret, frame = cap.read()
cap.release()

if not ret:
    print("cannot_read_video")
    exit(1)

print("loaded_frame")

gray = cv2.cvtColor(frame, cv2.COLOR_BGR2GRAY)
cv2.imwrite(os.path.join(OUTPUT_DIR, "gray_frame.png"), gray)

bit_planes = []

for bit in range(8):
    plane = ((gray >> bit) & 1).astype(np.uint8)
    bit_planes.append(plane)
    cv2.imwrite(os.path.join(OUTPUT_DIR, f"bit_plane_{bit}.png"), plane * 255)

print("created_8_bit_planes")

total_noise = 0
total_information = 0
total_blocks = 0
alpha_sum = 0.0

for bit_index, plane in enumerate(bit_planes):
    h, w = plane.shape
    noise_map = np.zeros((h, w), dtype=np.uint8)

    for y in range(0, h - BLOCK_SIZE + 1, BLOCK_SIZE):
        for x in range(0, w - BLOCK_SIZE + 1, BLOCK_SIZE):
            block = plane[y:y + BLOCK_SIZE, x:x + BLOCK_SIZE]

            alpha = calculate_complexity(block)

            if alpha < 0 or alpha > 1:
                print("invalid_alpha_value")
                exit(1)

            block_type = classify_block(alpha)

            if block_type == "noise":
                noise_map[y:y + BLOCK_SIZE, x:x + BLOCK_SIZE] = 255
                total_noise += 1
            elif block_type == "information":
                noise_map[y:y + BLOCK_SIZE, x:x + BLOCK_SIZE] = 80
                total_information += 1
            else:
                print("invalid_block_class")
                exit(1)

            total_blocks += 1
            alpha_sum += alpha

    cv2.imwrite(
        os.path.join(OUTPUT_DIR, f"noise_map_{bit_index}.png"),
        noise_map
    )

average_alpha = alpha_sum / total_blocks

print("calculated_complexity")
print("classified_blocks")
print("noisy_blocks:", total_noise)
print("information_blocks:", total_information)
print("average_alpha:", round(average_alpha, 4))
print("analysis_done")

with open(RESULT_PATH, "w") as f:
    f.write("loaded_frame\n")
    f.write("created_8_bit_planes\n")
    f.write("calculated_complexity\n")
    f.write("classified_blocks\n")
    f.write("analysis_done\n")
